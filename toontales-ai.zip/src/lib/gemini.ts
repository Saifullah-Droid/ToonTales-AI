import { GoogleGenAI, Type } from "@google/genai";
import { StoryInput } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateStory(input: StoryInput) {
  const model = "gemini-3-flash-preview";
  
  const prompt = `Create a personalized cartoon story for a child with the following details:
- Child Age: ${input.childAge}
- Child Personality: ${input.childPersonality}
- Parent Personality: ${input.parentPersonality}
- Theme: ${input.theme}
- Setting: ${input.setting}

The output must be a JSON object with:
1. title: A catchy title for the story.
2. storyText: The full story text (around 300-500 words), written in a child-friendly, engaging tone.
3. scenes: An array of 4 distinct scene descriptions that could be used as prompts for an image generator (e.g., "A magical forest with glowing mushrooms and a small rabbit wearing a tiny blue hat").

Make sure the story is heartwarming and aligns with the theme and setting.`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          storyText: { type: Type.STRING },
          scenes: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["title", "storyText", "scenes"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No story generated");
  return JSON.parse(text);
}

export async function generateImage(scenePrompt: string) {
  // Using gemini-2.5-flash-image for image generation as per guidelines
  const model = 'gemini-2.5-flash-image';
  
  const response = await ai.models.generateContent({
    model: model,
    contents: {
      parts: [
        {
          text: `Create a whimsical, family-friendly cartoon illustration for the following scene: ${scenePrompt}. The style should be vibrant, clean, and charming, like a modern children's book.`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
      },
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  
  return null;
}
