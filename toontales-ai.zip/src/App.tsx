import React, { useState, useEffect, MouseEvent } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { useCollection } from "react-firebase-hooks/firestore";
import { auth, db } from "./lib/firebase";
import { collection, addDoc, query, where, orderBy, serverTimestamp, deleteDoc, doc } from "firebase/firestore";
import { generateStory } from "./lib/gemini";
import { Story, StoryInput } from "./types";
import Navbar from "./components/layout/Navbar";
import StoryForm from "./components/story/StoryForm";
import StoryCard from "./components/story/StoryCard";
import StoryDisplayView from "./components/story/StoryDisplayView";
import { BookMarked, Sparkles, Wand2, Plus, Ghost } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [user] = useAuthState(auth);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [showGenerator, setShowGenerator] = useState(false);

  const [error, setError] = useState<string | null>(null);

  // Scroll to top when story is selected or show generator changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedStory, showGenerator]);

  // Fetch stories
  const storiesQuery = user 
    ? query(collection(db, "stories"), where("userId", "==", user.uid), orderBy("createdAt", "desc"))
    : null;
  const [value, loadingStories, firestoreError] = useCollection(storiesQuery);
  const stories = value?.docs.map(doc => ({ id: doc.id, ...doc.data() } as Story));

  useEffect(() => {
    if (firestoreError) {
      console.error("Firestore error:", firestoreError);
      setError("Failed to load your magical stories. Please check your connection.");
    }
  }, [firestoreError]);

  const handleGenerate = async (input: StoryInput) => {
    if (!user) return;
    setIsGenerating(true);
    setError(null);
    try {
      const generated = await generateStory(input);
      
      const newStory: Omit<Story, 'id'> = {
        userId: user.uid,
        ...input,
        ...generated,
        createdAt: serverTimestamp(),
      };

      const docRef = await addDoc(collection(db, "stories"), newStory);
      setSelectedStory({ id: docRef.id, ...newStory } as Story);
      setShowGenerator(false);
    } catch (err) {
      console.error("Story generation failed", err);
      setError("Oops! The magic wand stalled. There might be too much magic in the air—please try again in a moment.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteStory = async (e: MouseEvent, storyId: string) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this story?")) {
      try {
        await deleteDoc(doc(db, "stories", storyId));
      } catch (error) {
        console.error("Delete failed", error);
      }
    }
  };

  if (selectedStory) {
    return (
      <div className="min-h-screen font-sans">
        <Navbar />
        <StoryDisplayView 
          story={selectedStory} 
          onBack={() => setSelectedStory(null)} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans">
      <Navbar />

      <main className="max-w-6xl mx-auto px-4 py-12">
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600"
          >
            <Sparkles className="w-5 h-5 shrink-0" />
            <p className="text-sm font-medium">{error}</p>
            <button 
              onClick={() => setError(null)}
              className="ml-auto text-xs font-bold uppercase tracking-wider hover:underline"
            >
              Dismiss
            </button>
          </motion.div>
        )}
        
        {!user ? (
          <div className="text-center py-20">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="inline-block p-4 bg-indigo-50 rounded-3xl mb-8"
            >
              <Wand2 className="w-16 h-16 text-indigo-600" />
            </motion.div>
            <h1 className="text-5xl md:text-6xl font-black text-gray-900 mb-6 font-display">
              Where Every Child Is The <br />
              <span className="text-indigo-600 underline decoration-indigo-200 underline-offset-8">Hero Of Their Story</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
              Create personalized, AI-powered cartoon stories for your little ones in seconds. 
              Teach lessons, share adventures, and build memories.
            </p>
            <div className="flex justify-center gap-4">
              <div className="p-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
                <p className="text-2xl font-bold text-gray-900">0</p>
                <p className="text-xs text-gray-400 uppercase font-bold">Steps to Start</p>
              </div>
              <div className="p-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
                <p className="text-2xl font-bold text-gray-900">100%</p>
                <p className="text-xs text-gray-400 uppercase font-bold">Magic Guaranteed</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-12">
            <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <h1 className="text-4xl font-black text-gray-900 font-display">
                  Welcome back, {user.displayName?.split(' ')[0]}! 👋
                </h1>
                <p className="text-gray-500 mt-2 font-medium">Ready to weave another tale today?</p>
              </div>
              
              {!showGenerator && (
                <button
                  onClick={() => setShowGenerator(true)}
                  className="flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-indigo-100 hover:shadow-2xl hover:-translate-y-1 transition-all active:translate-y-0"
                >
                  <Plus className="w-6 h-6" />
                  Create New Story
                </button>
              )}
            </header>

            <AnimatePresence mode="wait">
              {showGenerator ? (
                <motion.div
                  key="generator"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="max-w-3xl mx-auto"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold flex items-center gap-2">
                      <Sparkles className="w-6 h-6 text-yellow-500" />
                      Story Generator
                    </h2>
                    <button 
                      onClick={() => setShowGenerator(false)}
                      className="text-gray-400 hover:text-gray-600 underline font-medium"
                    >
                      Maybe later
                    </button>
                  </div>
                  <StoryForm onGenerate={handleGenerate} isLoading={isGenerating} />
                </motion.div>
              ) : (
                <motion.div
                  key="list"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-8"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                      <BookMarked className="w-6 h-6" />
                    </div>
                    <h2 className="text-2xl font-bold">Your Story Collection</h2>
                  </div>

                  {loadingStories ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className="h-40 bg-white rounded-2xl animate-pulse border border-gray-100" />
                      ))}
                    </div>
                  ) : stories && stories.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {stories.map((story) => (
                        <div key={story.id}>
                          <StoryCard
                            story={story}
                            onClick={() => setSelectedStory(story)}
                            onDelete={(e) => handleDeleteStory(e, story.id!)}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-indigo-50/30 rounded-[2rem] p-12 text-center border-2 border-dashed border-indigo-100">
                      <div className="mx-auto w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-indigo-300 shadow-sm mb-6">
                        <Ghost className="w-10 h-10" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">No stories yet!</h3>
                      <p className="text-gray-500 mb-8 max-w-sm mx-auto">
                        Your magical bookshelf is empty. Let's create your first personalized story together!
                      </p>
                      <button
                        onClick={() => setShowGenerator(true)}
                        className="px-8 py-3 bg-white text-indigo-600 border border-indigo-200 rounded-xl font-bold shadow-sm hover:shadow-md transition-all active:scale-95"
                      >
                        Start Your First Tale
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </main>

      <footer className="mt-20 border-t border-gray-100 py-12 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <BookMarked className="w-5 h-5 text-indigo-600" />
            <span className="font-bold text-gray-400">ToonTales AI © 2026</span>
          </div>
          <div className="flex gap-8 text-sm font-medium text-gray-400">
            <a href="#" className="hover:text-indigo-600 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Contact Magic</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
