export interface UserProfile {
  uid: string;
  email: string;
  displayName: string | null;
  photoURL: string | null;
  createdAt: any;
}

export interface Story {
  id?: string;
  userId: string;
  childAge: string;
  childPersonality: string;
  parentPersonality: string;
  theme: string;
  setting: string;
  title: string;
  storyText: string;
  scenes: string[];
  imageUrls?: string[];
  createdAt: any;
}

export interface StoryInput {
  childAge: string;
  childPersonality: string;
  parentPersonality: string;
  theme: string;
  setting: string;
}
