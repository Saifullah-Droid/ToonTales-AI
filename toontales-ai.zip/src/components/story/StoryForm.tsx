import React, { useState } from "react";
import { StoryInput } from "../../types";
import { Sparkles, Baby, Users, MapPin, Palette } from "lucide-react";

interface StoryFormProps {
  onGenerate: (input: StoryInput) => void;
  isLoading: boolean;
}

export default function StoryForm({ onGenerate, isLoading }: StoryFormProps) {
  const [formData, setFormData] = useState<StoryInput>({
    childAge: "5",
    childPersonality: "curious and brave",
    parentPersonality: "supportive and funny",
    theme: "Sharing and Kindness",
    setting: "A magical hidden garden",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-8 shadow-xl border border-indigo-50 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
            <Baby className="w-4 h-4 text-pink-500" />
            Child's Age
          </label>
          <input
            type="number"
            value={formData.childAge}
            onChange={(e) => setFormData({ ...formData, childAge: e.target.value })}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            min="1"
            max="18"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
            <Users className="w-4 h-4 text-blue-500" />
            Child's Personality
          </label>
          <input
            type="text"
            placeholder="e.g. timid, adventurous, artistic"
            value={formData.childPersonality}
            onChange={(e) => setFormData({ ...formData, childPersonality: e.target.value })}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
            <Users className="w-4 h-4 text-purple-500" />
            Parent's Personality
          </label>
          <input
            type="text"
            placeholder="e.g. calm, high energy, storyteller"
            value={formData.parentPersonality}
            onChange={(e) => setFormData({ ...formData, parentPersonality: e.target.value })}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
            <Palette className="w-4 h-4 text-yellow-500" />
            Theme
          </label>
          <select
            value={formData.theme}
            onChange={(e) => setFormData({ ...formData, theme: e.target.value })}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all appearance-none"
            required
          >
            <option>Sharing and Kindness</option>
            <option>Overcoming Fears</option>
            <option>The Value of Honesty</option>
            <option>First Day of School</option>
            <option>Bedtime Adventure</option>
            <option>Learning to Help</option>
          </select>
        </div>

        <div className="md:col-span-2 space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
            <MapPin className="w-4 h-4 text-red-500" />
            Setting
          </label>
          <input
            type="text"
            placeholder="e.g. A space station, Under the ocean, A candy castle"
            value={formData.setting}
            onChange={(e) => setFormData({ ...formData, setting: e.target.value })}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            required
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-indigo-100 hover:shadow-2xl hover:scale-[1.01] transition-all disabled:opacity-70 disabled:scale-100 group"
      >
        {isLoading ? (
          <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
        ) : (
          <>
            <Sparkles className="w-6 h-6 group-hover:animate-pulse" />
            Create My Magic Story!
          </>
        )}
      </button>
    </form>
  );
}
