import React, { MouseEvent } from "react";
import { Story } from "../../types";
import { formatDate } from "../../lib/utils";
import { Book, Clock, Trash2, ChevronRight } from "lucide-react";

interface StoryCardProps {
  story: Story;
  onClick: () => void;
  onDelete: (e: MouseEvent) => void;
}

export default function StoryCard({ story, onClick, onDelete }: StoryCardProps) {
  return (
    <div
      onClick={onClick}
      className="group bg-white rounded-2xl p-5 border border-indigo-50 shadow-sm hover:shadow-md hover:border-indigo-100 transition-all cursor-pointer relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={onDelete}
          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
          <Book className="w-6 h-6" />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-gray-900 truncate pr-8">{story.title}</h3>
          <div className="flex flex-wrap items-center gap-3 mt-1">
            <span className="inline-flex items-center gap-1 text-xs font-medium text-gray-500">
              <Clock className="w-3 h-3" />
              {formatDate(story.createdAt)}
            </span>
            <span className="px-2 py-0.5 bg-indigo-50 text-indigo-600 text-[10px] font-bold rounded uppercase tracking-wider">
              {story.theme}
            </span>
          </div>
          <p className="mt-2 text-sm text-gray-600 line-clamp-2 leading-relaxed">
            {story.storyText}
          </p>
        </div>
        
        <div className="self-center">
          <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-indigo-400 transition-colors" />
        </div>
      </div>
    </div>
  );
}
