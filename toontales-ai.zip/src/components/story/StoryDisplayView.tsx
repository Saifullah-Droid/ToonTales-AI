import React, { useState } from "react";
import { Story } from "../../types";
import { generateImage } from "../../lib/gemini";
import { db } from "../../lib/firebase";
import { doc, updateDoc } from "firebase/firestore";
import { ArrowLeft, Image as ImageIcon, Sparkles, Wand2 } from "lucide-react";
import { motion } from "motion/react";

interface StoryDisplayViewProps {
  story: Story;
  onBack: () => void;
}

export default function StoryDisplayView({ story, onBack }: StoryDisplayViewProps) {
  const [imageUrls, setImageUrls] = useState<string[]>(story.imageUrls || []);
  const [isGeneratingImages, setIsGeneratingImages] = useState(false);

  const handleGenerateImages = async () => {
    if (!story.id) return;
    setIsGeneratingImages(true);
    try {
      const newImages = await Promise.all(
        story.scenes.map(scene => generateImage(scene))
      );
      const filteredImages = newImages.filter((img): img is string => img !== null);
      
      setImageUrls(filteredImages);
      await updateDoc(doc(db, "stories", story.id), {
        imageUrls: filteredImages
      });
    } catch (error) {
      console.error("Failed to generate images", error);
    } finally {
      setIsGeneratingImages(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-500 hover:text-indigo-600 transition-colors mb-6 font-medium"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Stories
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[2rem] overflow-hidden shadow-2xl border border-indigo-50"
      >
        <div className="p-8 md:p-12">
          <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-6 leading-tight bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            {story.title}
          </h1>

          <div className="flex flex-wrap gap-2 mb-10">
            <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-wider">
              Age: {story.childAge}
            </span>
            <span className="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-xs font-bold uppercase tracking-wider">
              {story.theme}
            </span>
            <span className="px-3 py-1 bg-pink-50 text-pink-700 rounded-full text-xs font-bold uppercase tracking-wider">
              {story.setting}
            </span>
          </div>

          <div className="prose prose-indigo max-w-none">
            <p className="text-xl md:text-2xl text-gray-800 leading-relaxed font-medium whitespace-pre-wrap first-letter:text-5xl first-letter:font-bold first-letter:mr-3 first-letter:float-left">
              {story.storyText}
            </p>
          </div>
        </div>

        <div className="bg-indigo-50/50 p-8 md:p-12 border-t border-indigo-100">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600">
                <Sparkles className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Illustration Scenes</h2>
            </div>
            
            {imageUrls.length === 0 && (
              <button
                onClick={handleGenerateImages}
                disabled={isGeneratingImages}
                className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-full font-bold shadow-lg hover:shadow-indigo-200 hover:scale-105 active:scale-95 transition-all disabled:opacity-70 disabled:scale-100"
              >
                {isGeneratingImages ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    Bring Story to Life!
                  </>
                )}
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {story.scenes.map((scene, idx) => (
              <div key={idx} className="space-y-4">
                <div className="relative group aspect-square rounded-3xl overflow-hidden bg-white shadow-inner border border-indigo-100">
                  {imageUrls[idx] ? (
                    <img
                      src={imageUrls[idx]}
                      alt={scene}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-300 p-8 text-center italic">
                      <ImageIcon className="w-12 h-12 mb-2 opacity-20" />
                      <p className="text-sm">Click 'Bring Story to Life' to generate illustrations</p>
                    </div>
                  )}
                </div>
                <div className="bg-white/60 p-4 rounded-2xl border border-indigo-50 text-sm text-gray-600 italic leading-relaxed">
                  "{scene}"
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
